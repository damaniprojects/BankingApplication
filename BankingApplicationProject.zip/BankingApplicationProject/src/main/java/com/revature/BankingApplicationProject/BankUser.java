package com.revature.BankingApplicationProject;

import java.io.Serializable;
import java.util.Map;

public class BankUser implements Serializable {
	private String username;
    private String userIDNumber;
    private String password;
    private boolean registered=false;
    private boolean signedIn=false;
    
    
    public void register(String username,String password){
        this.username = username;
        this.password = password;
        this.registered = true;
    }
    
    /* This doesn't allow taking a Map <String, Customer> as an argument. Why? */
    public void signIn(String username,String password, Map <String,BankUser> user){
    	for(Map.Entry<String, BankUser> u :user.entrySet()) {
    		if(u.getValue().getUsername().equals(username) && u.getValue().getPassword().equals(password)) {
    			System.out.printf("You're signed in as user %s \n\n",username);
                this.signedIn = true;
    	}else {
    		System.out.println("Sign in unsuccessful");
    	}
    	}
    }
    
    public void signIn(String username,String password){
    	if(username.equals(this.username) && password.equals(this.password)){
            System.out.printf("You're signed in as user %s \n\n",username);
            this.signedIn = true;
        }else {
        	System.out.println("Sign in unsuccessful\n\n");
        }
    }
    
    public boolean signedIn() {
    	return this.signedIn;
    }
    
    public void setUserName(String username){
        this.username = username;
    }
    
    public void setPassword(String password) {
    this.password = password;
    }
    
    public String getPassword() {
    	return this.password;
    }
    
    public String getUsername(){
        return this.username;
    }
    
    public String getUserIDNumber(){
        return this.userIDNumber;
    }
    
    public void generateID(){
        String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvxyz"; 
        int n = 6;
        StringBuilder sb = new StringBuilder(n); 
        for (int i = 0; i < n; i++) { 
            int index = (int)(AlphaNumericString.length() * Math.random()); 
            sb.append(AlphaNumericString.charAt(index)); 
        } 
        this.userIDNumber = sb.toString(); 
    }
}
