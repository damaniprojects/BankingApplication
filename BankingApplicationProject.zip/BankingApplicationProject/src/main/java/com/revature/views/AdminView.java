package com.revature.views;

public class AdminView {

}
