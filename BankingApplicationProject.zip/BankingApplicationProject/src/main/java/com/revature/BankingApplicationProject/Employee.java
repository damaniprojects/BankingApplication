/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.revature.BankingApplicationProject;

import java.io.Serializable;

/**
 *
 * @author damaniobie
 */
public class Employee extends BankUser implements Serializable{
    private String username;
    private String userIDNumber;
    private String password;
    boolean isEmployee = true;
    
    public Employee(){
        //this.username = username;
        this.generateID();
    }
    
    public boolean approve(Customer c){ //maybe take an owner parameter
        c.setApprovedStatus(true);
        return true;
    }
    
    public boolean deny(Customer c){
    	c.setApprovedStatus(false);
    	return false;
    }
    
    public void viewCustomer(Customer c){
    	 System.out.println("Name: "+c.getUsername()+"\n"
                 + "ID: "+c.getUserIDNumber()+"\n"
                 + "Number of accounts: "+c.getAccountList().size());
    	 System.out.println("Accoutn ID's: ");
    	 for(int i=0;i<c.getAccountList().size();i++) {
    		 //System.out.println(c.getAccountList().get());
    	 }
    }
    
    public void viewAccount(BankAccount b){
        b.seeAccountInfo();
    }
}
