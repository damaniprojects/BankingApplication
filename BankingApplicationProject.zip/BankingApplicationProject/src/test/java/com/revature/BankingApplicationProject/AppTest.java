package com.revature.BankingApplicationProject;

import com.revature.BankingApplicationProject.*;
import com.revature.Utils.*;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for simple App.
 */
public class AppTest extends TestCase
{
	
	static Customer c = new Customer();
	static BankAccount b= new BankAccount();
	
    /**
     * Create the test case
     *
     * @param testName name of the test case
     */
    public AppTest( String testName )
    {
        super( testName );
    }

    public void testGetAccountList() {
    	assertNotNull(c.getAccountList());
    }
    
    public void testBalance() {
    	b.setBalance(200);
    	assertEquals(200, b.getBalance());
    }
    
    /**
     * @return the suite of tests being tested
     */
    public static Test suite()
    {
        return new TestSuite( AppTest.class );
    }
    
    

    /**
     * Rigourous Test :-)
     */
    public void testApp()
    {
        assertTrue( true );
    }
}
