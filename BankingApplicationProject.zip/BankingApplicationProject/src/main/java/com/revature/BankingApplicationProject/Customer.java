/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.revature.BankingApplicationProject;
import  com.revature.BankingApplicationProject.BankAccount;
import java.io.Serializable;
import java.util.*;

/**
 *
 * @author damaniobie
 */
public class Customer extends BankUser implements Serializable{
    
    static List <Customer> customerApplications;
    private String username;
    private String userIDNumber;
    private String password;
    private boolean signedIn;
    private Map<String,BankAccount> accountList = new HashMap<String,BankAccount>();
    private boolean approvedForAccount=false;
    
    public Customer(){
        //this.setUserName(username);
        //this.accountList = new HashMap<String,BankAccount>();
        this.generateID();
    }
    
    public Customer(String username,boolean approvedForAccount, boolean signedIn) {
    	this.username = username;
    	this.userIDNumber = userIDNumber;
    	this.approvedForAccount = approvedForAccount;
    	this.signedIn = signedIn;
    	this.generateID();
    }
    
    public Map getAccountList(){
        return this.accountList;
    }
    
    public boolean hasAccount() {
    	if(this.accountList.size() > 0) {
    		return true;
    	}
    	return false;
    }
    
    public void setApprovedStatus(boolean b) {
    	 this.approvedForAccount = b;
    }
    public boolean getApprovedStatus() {
    	return this.approvedForAccount;
    }
    
    public void addAccount(){
        BankAccount b = new BankAccount();
        this.accountList.put(b.getAccountIDNumber(),b);
    }
    
    public void applyForAccount(Employee e){
        if(e.approve(this)){
            System.out.println("Account added");
            BankAccount b = new BankAccount();
            this.accountList.put(b.getAccountIDNumber(),b);
            System.out.println("Account ID: "+b.getAccountIDNumber()+"\n\n");
        }else{
            System.out.println("Your request was denied");
        }
    }
    
    public void applyJointAccount(Employee e){
        if(e.approve(this)){
            System.out.println("Account added");
            BankAccount b = new BankAccount();
            b.setIsJoint(true);
            this.accountList.put(b.getAccountIDNumber(),b);
            System.out.println("Account ID: "+b.getAccountIDNumber()+"\n\n");
        }else{
            System.out.println("Your request was denied");
        }
    }
    
    public void deposit(double amount,BankAccount ba){
        if(this.approvedForAccount){
            if(amount > 0){
            double t = ba.getBalance();
            t += amount;
            ba.setBalance(t);
            System.out.println("You have deposited into your account $"+amount);
            }else{
                System.out.println("Please enter a valid amount");
            }
        }
    }
    
    public void withdraw(double amount, BankAccount ba){
        if(this.approvedForAccount){
            double t = ba.getBalance();
            if(amount < t && amount > 0){
            t -= amount;
            ba.setBalance(t);
            System.out.printf("You have withdrawn from your account: $"+ amount);
            }else{
                System.out.print("Please enter a valid amount");
            }
        }
    }
    
    public void transfer(double amount, BankAccount b1, BankAccount b2){
        if(this.approvedForAccount){
        double t = b1.getBalance();
        double t2 = b2.getBalance();
        if(amount < t && amount > 0){
            t -= amount;
            t2 += amount;
            b1.setBalance(t);
            b2.setBalance(t2);
            System.out.println("You have transferred: $"+amount);
        }else {
        	System.out.println("You have entered an invalid amount");
        }
        }
        
    }
    
    public void seeAccount(BankAccount ba) {
    	if(ba != null) {
    	ba.seeAccountInfo();
    	}else {
    		System.out.println("That account number does not exist");
    	}
    }
    
    
    
}




