package com.revature.views;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

import com.revature.BankingApplicationProject.*;
import com.revature.Utils.Deserializer;
import com.revature.Utils.Serializer;
public class CustomerView implements View{
	
	
	
	Serializer serial = new Serializer();
	Deserializer deserial = new Deserializer();
	public Map<String,Customer> customerList = new HashMap<String, Customer>();
	InputStreamReader r=new InputStreamReader(System.in);    
    BufferedReader br=new BufferedReader(r);
    
	public void start() {
		
		/*
		customerMenu();
		
		Customer c = new Customer();
    	while(true) {
    	customerMenu();
    	while(true) {
    
    int y = Integer.parseInt(br.readLine());
    if(y == 1) {
    	System.out.println("Enter a username and password to register. \nUsername: ");
    	String u = br.readLine();
    	System.out.println("Password: ");
    	String p = br.readLine();
    	c.register(u, p);
    	customerList.put(c.getUserIDNumber(),c);
    	break;
    }else if(y==2) {
    	System.out.println("Enter your username");
    	String u = br.readLine();
    	System.out.println("Enter your password");
    	String p = br.readLine();
    	//c.signIn(u, p,customerList);
    	c.signIn(u, p);
    	break;
    }else if(y==3) {
    	if(c.signedIn()) {
    	System.out.println("Applying for account...");
    	Employee e = new Employee();
    	e.approve(c);
    	c.applyForAccount(e);
    	System.out.println("Congratulations");
    	}else {
    		System.out.println("You must sign in first");
    	}
    	break;
    }else if(y==4) {
    	if(c.signedIn()) {
    	System.out.println("Applying for joint account...");
    	Employee e = new Employee();
    	e.approve(c);
    	c.applyJointAccount(e);
    	System.out.println("Congratulations");
    	}else {
    		System.out.println("You must sign in");
    	}
    	
    	break;
    }else if(y==5) {
    	if(c.hasAccount()) {
    	System.out.println("Enter the account ID that you'd like to deposit.");
    	String id = br.readLine();
    	System.out.println("How much would you like to deposit?");
    	double amount = Double.parseDouble(br.readLine());
    	c.deposit(amount, (BankAccount) c.getAccountList().get(id));
    	}else {
    		System.out.println("Apply for an account first");
    	}
    	break;
    }else if(y==6) {
    	if(c.hasAccount()) {
    	System.out.println("Enter the account ID that you'd like to withdraw.");
    	String id = br.readLine();
    	System.out.println("How much would you like to withdraw?");
    	double amount = Double.parseDouble(br.readLine());
    	c.withdraw(amount, (BankAccount) c.getAccountList().get(id));
    	}else {
    		System.out.println("Apply for an account first");
    	}
    	break;
    }else if(y==7) {
    	if(c.hasAccount()) {
    	System.out.println("Enter the account ID that you'd like to transfer from.");
    	String id = br.readLine();
    	System.out.println("Enter the account ID that you'd like to transfer to.");
    	String id2 = br.readLine();
    	System.out.println("How much would you like to transfer?");
    	double amount = Double.parseDouble(br.readLine());
    	c.transfer(amount, (BankAccount) c.getAccountList().get(id),(BankAccount) c.getAccountList().get(id2));
    	}else {
    		System.out.println("Apply for an account first");
    	}
    	break;
    }else if(y==8) {
    	if(c.hasAccount()) {
    	System.out.println("Enter the accounts ID number");
    	String id = br.readLine();
    	c.seeAccount((BankAccount) c.getAccountList().get(id));
    	}
    	break;
    }else if(y==9) {
    	if(c.signedIn()) {
    	System.out.println("Log out successful\n\n");
    	break loop;
    	}
    	break;
    }
    }
    	serial.serializeUser(c);
    	c = (Customer) deserial.deserialize();
    	
    	break;
    }
		*/
	}
	
	static void customerMenu(){
        System.out.println("What would you like to do?\n1. Register a user"
                + "\n2. Sign in\n3. Apply for an account\n4. Apply for a joint account"
                + "\n5. Deposit funds\n6. Withdraw\n7. Transfer funds\n8. Check account info \n9. Logout");
    }
    
    
}
