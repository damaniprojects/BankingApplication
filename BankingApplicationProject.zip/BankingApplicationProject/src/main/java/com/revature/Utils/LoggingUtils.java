package com.revature.Utils;
import org.apache.log4j.Logger;

public class LoggingUtils {    
	
	private static Logger log = Logger.getRootLogger();

    

    // Tracing step by step through application

    public void logTrace(String msg) {

        log.trace(msg);

    }

    

    // Used to check for example specific value at specific place of a variable

    public void logDebug(String msg) {

        log.debug(msg);

    }

    

    // Used to log information in general for example whenever a user logs in

    public void logInfo(String msg) {

        log.info(msg);

    }

    

    // in catch blocks for example logging that an exception has occured and information about it

    public void logWarn(String msg) {

        log.warn(msg);

    }

    

    // when an error occurs you log information about the error

    public void logError(String msg) {

        log.error(msg);

    }

    

    // When your application crashes you try to log as many data about the program before it crashes

    public void logFatal(String msg) {

        log.fatal(msg);

    }

    

}