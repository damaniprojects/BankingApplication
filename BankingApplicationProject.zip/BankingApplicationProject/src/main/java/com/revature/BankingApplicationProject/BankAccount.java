package com.revature.BankingApplicationProject;
import java.io.Serializable;
import java.util.List;


/**
 *
 * @author damaniobie
 */
public class BankAccount implements Serializable{
    
    private double balance;
    private List <Customer> owners;
    private boolean isOpen=false;
    private boolean isJoint = false;
    private String accountIDNumber;
    
    public BankAccount(){
        this.generateAccountIDNumber();
        this.isOpen = true;
    }
    
    public BankAccount(double balance, boolean isJoint,boolean isOpen) {
    	this.generateAccountIDNumber();
    	this.balance = balance;
    	this.isJoint=isJoint;
    	this.isOpen = isOpen;
    }
    
    public boolean getIsOpen(){
        return this.isOpen;
    }
    
    public boolean getIsJoint(){
        return this.isJoint;
    }
    
    public void setIsOpen(boolean b){
        this.isOpen = b;
    }
    
    public void setIsJoint(boolean b){
        this.isJoint = b;
    }
    
    public double getBalance(){
        return this.balance;
    }
    
    public void setBalance(double d){
        this.balance = d;
    }
    
    public void seeOwnerInfo(){
        for(int i=0;i<this.owners.size();i++){
             System.out.println("Name: "+this.owners.get(i).getUsername()+"\n"
                     + "ID: "+this.owners.get(i).getUserIDNumber()+"\n"
                     + "Number of accounts: "+this.owners.get(i).getAccountList().size());
             System.out.println();
        }
    }
    
    public void seeAccountInfo(){
        System.out.println("Balance: "+this.balance+"\nAccountID: "+this.accountIDNumber+
                  "\nNumber of Owners: "+this.owners.size()+""
                + "\nIs Open: "+this.isOpen+"\nIs Joint Account: "+this.isJoint);
    }
    
    public String getAccountIDNumber() {
    	return this.accountIDNumber;
    }
    
    public void generateAccountIDNumber(){
        String AlphaNumericString = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789abcdefghijklmnopqrstuvxyz"; 
        int n = 7;
        StringBuilder sb = new StringBuilder(n); 
        for (int i = 0; i < n; i++) { 
            int index = (int)(AlphaNumericString.length() * Math.random()); 
            sb.append(AlphaNumericString.charAt(index)); 
        } 
        this.accountIDNumber = "AC-"+sb.toString(); 
    }
    
}
