/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.revature.BankingApplicationProject;

import java.io.Serializable;

/**
 *
 * @author damaniobie
 */
public class Admin extends BankUser implements Serializable{
    private String username;
    private String userIDNumber;
    private String password;
    
    public Admin(){
       // this.username = username;
        this.generateID();
    }
    
    
    public void withdraw(double amount, BankAccount ba){
    	double t = ba.getBalance();
        if(amount < t && amount > 0){
        t -= amount;
        ba.setBalance(t);
        System.out.printf("You have withdrawn %d from your account",amount);
        }else{
            System.out.print("Please enter a valid amount");
        }
    }
    
    public void deposit(double amount, BankAccount ba){
    	if(amount > 0){
            double t = ba.getBalance();
            t += amount;
            ba.setBalance(t);
            System.out.printf("You have deposited %d into your account",amount);
            }else{
                System.out.println("Please enter a valid amount");
            }
    }
    
    public void transferToAccount(double amount, BankAccount b1, BankAccount b2){
    	double t = b1.getBalance();
        double t2 = b2.getBalance();
        if(amount < t && amount > 0){
            t -= amount;
            t2 += amount;
            b1.setBalance(t);
            b2.setBalance(t2);
            System.out.printf("You have transferred %d",amount);
        }
    }
    
    public void cancelCustomerAccount(BankAccount ba){
        ba.setIsOpen(false);
    }
}
