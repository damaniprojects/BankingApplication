package com.revature.views;

import java.io.IOException;

public interface View {
	
	public void start() throws NumberFormatException, IOException;
	
}
