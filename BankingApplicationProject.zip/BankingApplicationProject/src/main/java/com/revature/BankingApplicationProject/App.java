/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.revature.BankingApplicationProject;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.*;
import com.revature.Utils.LoggingUtils;
import com.revature.Utils.Deserializer;
import com.revature.Utils.Serializer;
/**
 *
 * @author damaniobie
 */


public class App {
    

   static Map<String, Customer> customerList = new HashMap<String , Customer>();
   static Map<String, Employee> employeeList = new HashMap<String,Employee>();
   static Map<String,Admin> adminList = new HashMap<String,Admin>();
   static Map<String,BankAccount> accountList = new HashMap<String,BankAccount>();
   static Map <Customer,BankAccount> m = new HashMap<Customer,BankAccount>();
   static Random rand = new Random();
    
    public static void main(String[]args) throws IOException{
    	Serializer serial = new Serializer();
    	Deserializer deserial = new Deserializer();
    	InputStreamReader r=new InputStreamReader(System.in);    
        BufferedReader br=new BufferedReader(r); 
        
        LoggingUtils log = new LoggingUtils();
        Scanner scan = new Scanner(System.in);
      /*  BankAccount bank = new BankAccount();
        accountList.put("AC-aaaaa",bank);
        Customer c1 = new Customer();
        c1.getAccountList().put("AC-aaaaa",bank);*/
        
        
        
        
        menu();
        int x = Integer.parseInt(br.readLine());
        loop:
        switch(x) {
        case 1:
        	Customer c = new Customer();
        	while(true) {
        	customerMenu();
        	while(true) {
        
        int y = Integer.parseInt(br.readLine());
        if(y == 1) {
        	System.out.println("Enter a username and password to register. \nUsername: ");
        	String u = br.readLine();
        	System.out.println("Password: ");
        	String p = br.readLine();
        	c.register(u, p);
        	customerList.put(c.getUserIDNumber(),c);
        	break;
        }else if(y==2) {
        	System.out.println("Enter your username");
        	String u = br.readLine();
        	System.out.println("Enter your password");
        	String p = br.readLine();
        	//c.signIn(u, p,customerList);
        	c.signIn(u, p);
        	break;
        }else if(y==3) {
        	if(c.signedIn()) {
        	System.out.println("Applying for account...");
        	Employee e = new Employee();
        	e.approve(c);
        	c.applyForAccount(e);
        	System.out.println("Congratulations");
        	}else {
        		log.logWarn("Must be signed in");
        	}
        	break;
        }else if(y==4) {
        	if(c.signedIn()) {
        	System.out.println("Applying for joint account...");
        	Employee e = new Employee();
        	e.approve(c);
        	c.applyJointAccount(e);
        	}else {
        		log.logWarn("Must be signed in");
        	}
        	
        	break;
        }else if(y==5) {
        	if(c.hasAccount()) {
        	System.out.println("Enter the account ID that you'd like to deposit.");
        	String id = br.readLine();
        	System.out.println("How much would you like to deposit?");
        	double amount = Double.parseDouble(br.readLine());
        	c.deposit(amount, (BankAccount) c.getAccountList().get(id));
        	}else {
        		log.logWarn("Must apply for account");
        	}
        	break;
        }else if(y==6) {
        	if(c.hasAccount()) {
        	System.out.println("Enter the account ID that you'd like to withdraw.");
        	String id = br.readLine();
        	System.out.println("How much would you like to withdraw?");
        	double amount = Double.parseDouble(br.readLine());
        	c.withdraw(amount, (BankAccount) c.getAccountList().get(id));
        	}else {
        		log.logWarn("Must apply for account");
        	}
        	break;
        }else if(y==7) {
        	if(c.hasAccount()) {
        	System.out.println("Enter the account ID that you'd like to transfer from.");
        	String id = br.readLine();
        	System.out.println("Enter the account ID that you'd like to transfer to.");
        	String id2 = br.readLine();
        	System.out.println("How much would you like to transfer? Max: $"+((BankAccount) c.getAccountList().get(id)).getBalance());
        	double amount = Double.parseDouble(br.readLine());
        	c.transfer(amount, (BankAccount) c.getAccountList().get(id),(BankAccount) c.getAccountList().get(id2));
        	}else {
        		log.logWarn("Must apply for account");
        	}
        	break;
        }else if(y==8) {
        	if(c.hasAccount()) {
        	System.out.println("Enter the accounts ID number");
        	String id = br.readLine();
        	try {
        	c.seeAccount((BankAccount) c.getAccountList().get(id));
        	}catch(NullPointerException e) {
        		e.printStackTrace();
        	}
        	}
        	break;
        }else if(y==9) {
        	if(c.signedIn()) {
        	System.out.println("Log out successful\n\n");
        	break loop;
        	}
        	break;
        }
        }
        	serial.serializeUser(c);
        	c = (Customer) deserial.deserialize();
        	
        	
        }
        	
        	
        
        case 2:
        simulate();
        Employee e = new Employee();
    	while(true) {
    		employeeMenu();
    	while(true) {
    
    int y = Integer.parseInt(br.readLine());
    if(y == 1) {
    	System.out.println("Enter a username and password to register. \nUsername: ");
    	String u = br.readLine();
    	System.out.println("Password: ");
    	String p = br.readLine();
    	e.register(u, p);
    	employeeList.put(e.getUserIDNumber(),e);
    	break;
    }else if(y==2) {
    	System.out.println("Enter your username and password");
    	String u = br.readLine();
    	System.out.println("Enter your password");
    	String p = br.readLine();
    	e.signIn(u, p);
    	break;
    }else if(y==3) {
    	System.out.println("Now going through the list of customers who haven't yet been approved."
    			+ "\nPress 'a' to approve, and press 'd' to deny");
    	for(Map.Entry<String, Customer> cu :customerList.entrySet()) {
    		if(!cu.getValue().getApprovedStatus()) {
    			System.out.println("Press 'a' to approve this customer, press 'd' to deny.");
    			System.out.println("Name: "+cu.getValue().getUsername()+"\nID: "+cu.getValue().getUserIDNumber());
    			char s = br.readLine().charAt(0);
    			if(s == 'a' || s =='A') {
    				e.approve(cu.getValue());
    				System.out.printf("Customer"+ cu.getValue().getUsername()+"approved!");
    			}else if(s=='d' || s == 'D') {
    				e.deny(cu.getValue());
    				System.out.printf("Customer"+ cu.getValue().getUsername()+"denied!");
    			}else {
    				log.logWarn("Invalid input");
    			}
    		}
    	}
    	break;
    		}else if(y == 4){
    				System.out.println("Enter the customers ID number");
    				String id =br.readLine();
    				if(customerList.containsKey(id)) {
    				e.viewCustomer(customerList.get(id));
    				}else {
    					log.logWarn("invalid id");
    				}
    				break;
    		}else if(y==5) {
    			System.out.println("Enter the account ID number");
				String id = br.readLine();
				if(accountList.containsKey(id)) {
				e.viewAccount(accountList.get(id));
				}else {
					log.logWarn("invalid id");
				}
				break;
    		}
    	}
    	serial.serializeUser(e);
    	e = (Employee) deserial.deserialize();
    
    }
    	
    	
        
        case 3:
        simulate();
        Admin a = new Admin();
    	while(true) {
    		adminMenu();
    	while(true) {
    
    int y = Integer.parseInt(br.readLine());
    if(y == 1) {
    	System.out.println("Enter a username and password to register. \nUsername: ");
    	String u = br.readLine();
    	System.out.println("Password: ");
    	String p = br.readLine();
    	a.register(u, p);
    	adminList.put(a.getUserIDNumber(),a);
    	break;
    }else if(y==2) {
    	System.out.println("Enter your username and password");
    	String u = br.readLine();
    	System.out.println("Enter your password");
    	String p = br.readLine();
    	a.signIn(u, p);
    	break;
    }else if(y==3) {
    	System.out.println("Enter the account ID that you'd like to deposit.");
    	String id = br.readLine();
    	System.out.println("How much would you like to deposit?");
    	double amount = Double.parseDouble(br.readLine());
    	a.deposit(amount, accountList.get(id));
    	break;
    }else if(y==4) {
    	System.out.println("Enter the account ID that you'd like to withdraw.");
    	String id = br.readLine();
    	System.out.println("How much would you like to withdraw?");
    	double amount = Double.parseDouble(br.readLine());
    	a.withdraw(amount, accountList.get(id));
    	break;
    }else if(y==5) {
    	System.out.println("Enter the account ID that you'd like to transfer from.");
    	String id = br.readLine();
    	System.out.println("Enter the account ID that you'd like to transfer to.");
    	String id2 = br.readLine();
    	System.out.println("How much would you like to transfer?");
    	double amount = Double.parseDouble(br.readLine());
    	a.transferToAccount(amount, accountList.get(id),accountList.get(id2));
    	break;
    }
    }
    	serial.serializeUser(a);
    	a = (Admin) deserial.deserialize();
    	
    	}
    	
    	default:log.logWarn("Must apply for account");
    	break;
    	
    	
    	
    	
    }
        }
        
    static void menu(){
        System.out.println("Are you a\n1. customer\n2. employee\n3. admin\n");
    }
    static void customerMenu(){
        System.out.println("What would you like to do?\n1. Register a user"
                + "\n2. Sign in\n3. Apply for an account\n4. Apply for a joint account"
                + "\n5. Deposit funds\n6. Withdraw\n7. Transfer funds\n8. Check account info \n9. Logout");
    }
    
    static void employeeMenu(){
        System.out.println("What would you like to do?\n1. Register a user" + 
        		"\n2. Sign in\n3. Approve or Deny users\n4. View customer info" + 
        		"\n5. View Account info\n6. Log out");
    }
    
    static void adminMenu(){
    	System.out.println("What would you like to do?\n1. Register a user" + 
        		"\n2. Sign in\n3. Deposit \n4. Withdraw" + 
        		"\n5. Transfer\n6. Cancel Account\n7. Log out");
    }
    
    static String randName() {
    	String lexicon = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    	StringBuilder builder = new StringBuilder();
    	Set<String> identifiers = new HashSet<String>();
        while(builder.toString().length() == 0) {
            int length = rand.nextInt(5)+5;
            for(int i = 0; i < length; i++) {
                builder.append(lexicon.charAt(rand.nextInt(lexicon.length())));
            }
            if(identifiers.contains(builder.toString())) {
                builder = new StringBuilder();
            }
        }
        return builder.toString();
    	
    }
    static void simulate() {
    	boolean rand1=true,rand2=false,rand3=true,rand4=false;
    	int y = (int) (Math.random()*100+1);
    	if(y % 2 == 0) {
    		rand1 = true;
    		rand2 =false;
    		rand3 = true;
    		rand4 = false;
    	}
    	for(int i=0;i<10;i++) {
    	double x = Math.random() * 10000 + 1;
    	String name = randName();
    	Customer customer = new Customer(name,rand1, rand2);
    	BankAccount ba = new BankAccount(x,rand3,rand4);
    	customer.getAccountList().put(ba.getAccountIDNumber(), ba);
    	customerList.put(customer.getUserIDNumber(), customer);
    	accountList.put(ba.getAccountIDNumber(), ba);
    	System.out.println("Customer ID: "+customer.getUserIDNumber()+"\tAccout ID: "+ba.getAccountIDNumber());
    	
    	}
    	
    }
}
